#include "stdafx.h"
#include "Bullet.h"
#include "commonFunction.h"

Bullet::Bullet()
{
	pos.x = 0;
	pos.y = 0;
	speed = 10;
	size = 20;
	isFire = false;
}

void Bullet::Move()
{
	if (isFire) 
	{
		pos.x += cosf(angle) * speed;
		pos.y += -sinf(angle) * speed;

		//�����ʿ� �ε����� ���
		if (pos.x + size > WINWIDTH)
		{
			angle = PI - angle;
			pos.x = WINWIDTH - size;
		}
		if (pos.x - size < 0)
		{
			angle = 3 * PI - angle;
			pos.x = 0 + size;
		}
		if (pos.y + size > WINHEIGHT)
		{
			angle = (2 * PI) - angle;
			pos.y = WINHEIGHT - size;
		}
		if (pos.y - size < 0)
		{
			angle = (2 * PI) - angle;
			pos.y = 0 + size;
		}
	}
}

void Bullet::Fire()
{
	isFire = true;
}

void Bullet::Draw(HDC hdc)
{
	if (isFire)
	{
		MakeCircle(hdc, pos, size);
	}
}
