#include "stdafx.h"
#include "Cannon.h"
#include "commonFunction.h"

Cannon::Cannon()
{
	pos.x = 500;
	pos.y = 500;

	endPos = pos;

	angle = PI/2;

	radius = 50;
	length = 100;
	Bullet b;
	bv.push_back(b);
}

void Cannon::Update(WPARAM wParam)
{
	switch (wParam)
	{
	case VK_UP:
		angle += 0.1f;
		break;
	case VK_DOWN:
		angle -= 0.1f;
		break;
	default:
		break;
	}

	endPos.x = cosf(angle) * length + pos.x;
	endPos.y = -sinf(angle) * length + pos.y;	
}

void Cannon::Update()
{
	if (GetAsyncKeyState(VK_UP))
	{
		angle += 0.1f;
	}

	if (GetAsyncKeyState(VK_DOWN))
	{
		angle -= 0.1f;
	}

	if (GetAsyncKeyState(VK_SPACE) & 0x8000)
	{//�������� ��
		/*bullet->Fire();
		bullet->SetPos(endPos);
		bullet->SetAngle(angle);*/
		BulletF();
	}
	else
	{//���� ��

	}

	endPos.x = cosf(angle) * length + pos.x;
	endPos.y = -sinf(angle) * length + pos.y;

	//bullet->Move();
	BulletM();
}

void Cannon::DrawCannon(HDC hdc)
{
	//ĳ�� ����׸���
	MakeCircle(hdc, pos, radius);
	//���� �׸��� - ĳ�� �߽ɿ��� ���� �������� ������
	MakeLine(hdc, pos, endPos);

	//bullet->Draw(hdc);
	BulletD(hdc);
}

void Cannon::BulletF()
{
	Bullet* bullet = CheckBullet();
	bullet->Fire();
	bullet->SetPos(endPos);
	bullet->SetAngle(angle);
}

Bullet* Cannon::CheckBullet()
{
	Bullet b;
	while (true)
	{
		for (int i = 0; i < bv.size(); i++)
		{
			if (bv[i].isFire == false)
			{
				return &bv[i];
			}
		}
		bv.push_back(b);
	}
}

void Cannon::BulletM()
{
	for (int i = 0; i < bv.size(); i++)
	{
		bv[i].Move();
	}
}

void Cannon::BulletD(HDC hdc)
{
	for (int i = 0; i < bv.size(); i++)
	{
		bv[i].Draw(hdc);
	}
}
