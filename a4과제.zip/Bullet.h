#pragma once
#include "stdafx.h"

class Bullet
{
private:
	POINT pos;
	int size;
	int speed;
	float angle;

public:
	bool isFire;
	Bullet();
	void Move();
	void Fire();
	void Draw(HDC hdc);

	inline void SetPos(POINT p) { pos = p; }
	inline void SetAngle(float a) { angle = a; }
};