#include "DoubleBuffering.h"
#include "Draw.h"

using namespace std;

#define MAPSIZE 20

void main()
{
	Draw draw;

	draw.CreateBuffer(MAPSIZE*2, MAPSIZE);
	
	string str;

	for (int i = 0 ; i < MAPSIZE; i++)
	{
		for (int j = 0; j < MAPSIZE; j++)
		{
			str += "��";
		}
		str += "\n";
	}

	for (int i = 0; i < draw.size - 1; i++)
	{		
		draw.map[i] = str[i];
	}

	draw.map[draw.size - 1] = NULL;

	while (true)
	{
		draw.Clear();
		draw.Print();
		draw.Flipping();		
	}
}