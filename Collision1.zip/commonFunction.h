#pragma once
#include "stdafx.h"

inline void MakeSquare(HDC hdc, POINT pos, int size)
{
	Rectangle(hdc, pos.x, pos.y, pos.x + size, pos.y + size);
}

inline void MakeRect(HDC hdc, RECT rc)
{
	Rectangle(hdc, rc.left, rc.top, rc.right, rc.bottom);
}

inline void MakeCircle(HDC hdc, POINT centerPos, int radius)
{
	Ellipse(hdc, centerPos.x - radius, centerPos.y - radius,
		centerPos.x + radius, centerPos.y + radius);
}

//�׸�� ���� �浹ó��
inline bool IsCollision(RECT rc, POINT pos)
{
	if (rc.left < pos.x && rc.right > pos.x)
	{
		if (rc.top < pos.y && rc.bottom > pos.y)
		{
			return true;
		}
	}

	return false;
}

//�׸�� �׸��� �浹ó��
inline bool IsCollision(RECT rc1, RECT rc2)
{
	if (rc1.right > rc2.left && rc1.left < rc2.right)
	{
		if (rc1.top < rc2.bottom && rc1.bottom > rc2.top)
		{
			return true;
		}
	}

	return false;
}

inline int GetDistance(POINT pos1, POINT  pos2)
{
	int x = pos1.x - pos2.x;
	int y = pos1.y - pos2.y;

	int d = (int)sqrt(x*x + y*y);

	return d;
}

//���� ���� �浹ó��
inline bool IsCollision(POINT centerPos, int radius, POINT pos)
{
	if (GetDistance(centerPos, pos) < radius)
	{
		return true;
	}

	return false;
}

