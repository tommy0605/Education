#pragma once

class Character
{
public:
	string name;
	string pw;
	int level;

	Character()
	{
		name = "";
		pw = "";
		level = 0;
	}

	void ShowInfo()
	{
		cout << "�̸� : " << name << endl;
		cout << "���� : " << level << endl;
	}
};