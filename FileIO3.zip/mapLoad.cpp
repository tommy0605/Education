#include <iostream>
#include <string>
#include <fstream>
#include <vector>
#include <map>
#include <string.h>

#define MAPSIZE 5

using namespace std;

struct Point
{
	int x;
	int y;
};

int intMap[MAPSIZE][MAPSIZE];
Point player;

vector<string> LoadMap()
{
	vector<string> map;

	ifstream load("map.txt");

	for (int i = 0; i < MAPSIZE; i++)
	{
		string str;
		load >> str;
		map.push_back(str);
		for (int j = 0; j < MAPSIZE; j++)
		{
			char c = str[j];
			//int a = c;
			//cout << j << " : " << c << " = " << a << endl;
			//j=0 : c='1';
			intMap[i][j] = c - '0';
		}
	}

	return map;
}

void PrintMap()
{
	for (int i = 0; i < MAPSIZE ; i++)
	{
		for (int j = 0; j < MAPSIZE; j++)
		{			
			if (i == player.x && j == player.y)
			{
				cout << "��";
			}else if (intMap[i][j] == 0)
			{
				cout << "  ";
			}
			else if (intMap[i][j] == 1)
			{
				cout << "��";
			}
		}
		cout << endl;
	}
}

void PrintMap(vector<string> map)
{
	for (int i = 0; i < map.size(); i++)
	{
		for (int j = 0; j < map[i].size(); j++)
		{
			if (map[i][j] == '0')
			{
				map[i][j] = ' ';
			}			
		}
		cout << map[i] << endl;
	}
}

void main()
{
	player.x = 1;
	player.y = 1;
	LoadMap();
	PrintMap();
}

void main1()
{
	vector<string> map = LoadMap();
	PrintMap(map);
}

void main2()
{
	map<int, int> mapData;

	mapData[0] = 4;
	mapData[5] = 10;
	mapData[7] = 11;

	mapData.insert(make_pair(9, 22));

	map<int, int>::iterator it;
	for (it = mapData.begin(); it != mapData.end(); it++)
	{
		cout << "Ű�� : " << it->first << endl;
		cout << "������ : " << it->second << endl;
	}

	cout << "Ű���� �Է��Ͻÿ�" << endl;
	int key;
	cin >> key;

	it = mapData.find(key);

	if (it == mapData.end())
	{
		cout << "���ϴ� �����Ͱ� �����ϴ�." << endl;
	}
	else
	{
		cout << "������ : " << it->second << endl;
	}
}