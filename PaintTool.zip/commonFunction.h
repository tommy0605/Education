#pragma once
#include "stdafx.h"

inline void MakeLine(HDC hdc, POINT startPos, POINT endPos)
{
	MoveToEx(hdc, startPos.x, startPos.y, NULL);
	LineTo(hdc, endPos.x, endPos.y);
}

inline void MakeRect(HDC hdc, POINT startPos, POINT endPos)
{
	Rectangle(hdc, startPos.x, startPos.y, endPos.x, endPos.y);
}

inline void MakeEllipse(HDC hdc, POINT startPos, POINT endPos)
{
	Ellipse(hdc, startPos.x, startPos.y, endPos.x, endPos.y);
}